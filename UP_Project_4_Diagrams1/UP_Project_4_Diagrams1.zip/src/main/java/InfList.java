import java.util.ArrayList;

public class InfList {
	public String nameString;
	ArrayList<Information>list;
}
