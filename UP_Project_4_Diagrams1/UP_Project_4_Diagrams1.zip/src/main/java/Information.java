public class Information {
	public String name;
	public int numberOf;
}
