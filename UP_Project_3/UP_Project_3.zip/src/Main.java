import java.util.ArrayList;
import java.util.List;

public class Main {
	public static final String PATH_STRING="C:/Java-eclipse-workspace/UP_Project_3/shadow/";
	public static final int CELL_WH=48;
	public static void main(String[] args) {
		new Window();
	}
}
