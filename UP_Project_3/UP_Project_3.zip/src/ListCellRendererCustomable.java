import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class ListCellRendererCustomable implements ListCellRenderer<Tour> {

	@Override
	public Component getListCellRendererComponent(JList<? extends Tour> arg0, Tour arg1, int arg2, boolean arg3,
			boolean arg4) {
		return new JLabel(arg1.getCountryName(),arg1.getCountryIcon(),JLabel.LEFT);
	}

}
